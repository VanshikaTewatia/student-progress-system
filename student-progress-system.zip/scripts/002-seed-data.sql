-- Insert sample students
INSERT INTO students (name, email, phone, codeforces_handle, current_rating, max_rating, last_submission_date) VALUES
('Alice Johnson', 'alice@example.com', '+1234567890', 'alice_codes', 1542, 1687, CURRENT_TIMESTAMP - INTERVAL '2 days'),
('Bob Smith', 'bob@example.com', '+1234567891', 'bob_solver', 1234, 1456, CURRENT_TIMESTAMP - INTERVAL '5 days'),
('Charlie Brown', 'charlie@example.com', '+1234567892', 'charlie_cf', 1876, 1923, CURRENT_TIMESTAMP - INTERVAL '10 days'),
('Diana Prince', 'diana@example.com', '+1234567893', 'diana_dev', 1098, 1298, CURRENT_TIMESTAMP - INTERVAL '1 day'),
('Eve Wilson', 'eve@example.com', '+1234567894', 'eve_expert', 2134, 2234, CURRENT_TIMESTAMP - INTERVAL '15 days');

-- Insert sample contest data
INSERT INTO contests (student_id, contest_id, contest_name, rank, old_rating, new_rating, rating_change, problems_solved, total_problems, contest_time) VALUES
(1, 1001, 'Codeforces Round #900', 234, 1500, 1542, 42, 3, 6, CURRENT_TIMESTAMP - INTERVAL '5 days'),
(1, 1002, 'Educational Round #150', 456, 1542, 1687, 145, 4, 7, CURRENT_TIMESTAMP - INTERVAL '15 days'),
(2, 1001, 'Codeforces Round #900', 567, 1200, 1234, 34, 2, 6, CURRENT_TIMESTAMP - INTERVAL '5 days'),
(3, 1001, 'Codeforces Round #900', 123, 1850, 1876, 26, 4, 6, CURRENT_TIMESTAMP - INTERVAL '5 days'),
(4, 1002, 'Educational Round #150', 789, 1050, 1098, 48, 2, 7, CURRENT_TIMESTAMP - INTERVAL '15 days');

-- Insert sample problem data
INSERT INTO problems (student_id, problem_id, problem_name, rating, tags, solved_at) VALUES
(1, '1A', 'Theatre Square', 1000, ARRAY['math', 'implementation'], CURRENT_TIMESTAMP - INTERVAL '2 days'),
(1, '1B', 'Spreadsheets', 1200, ARRAY['implementation', 'strings'], CURRENT_TIMESTAMP - INTERVAL '3 days'),
(1, '1C', 'Ancient Berland Circus', 1600, ARRAY['geometry', 'math'], CURRENT_TIMESTAMP - INTERVAL '5 days'),
(2, '1A', 'Theatre Square', 1000, ARRAY['math', 'implementation'], CURRENT_TIMESTAMP - INTERVAL '5 days'),
(2, '2A', 'Winner', 1100, ARRAY['implementation', 'data structures'], CURRENT_TIMESTAMP - INTERVAL '7 days'),
(3, '1A', 'Theatre Square', 1000, ARRAY['math', 'implementation'], CURRENT_TIMESTAMP - INTERVAL '10 days'),
(3, '1B', 'Spreadsheets', 1200, ARRAY['implementation', 'strings'], CURRENT_TIMESTAMP - INTERVAL '12 days'),
(3, '1C', 'Ancient Berland Circus', 1600, ARRAY['geometry', 'math'], CURRENT_TIMESTAMP - INTERVAL '15 days'),
(3, '1D', 'Two Paths', 1800, ARRAY['graphs', 'shortest paths'], CURRENT_TIMESTAMP - INTERVAL '18 days');

-- Insert sample submission data for heatmap
INSERT INTO submissions (student_id, submission_date, problem_count) VALUES
(1, CURRENT_DATE - INTERVAL '1 day', 2),
(1, CURRENT_DATE - INTERVAL '2 days', 3),
(1, CURRENT_DATE - INTERVAL '5 days', 1),
(1, CURRENT_DATE - INTERVAL '10 days', 4),
(2, CURRENT_DATE - INTERVAL '5 days', 1),
(2, CURRENT_DATE - INTERVAL '7 days', 2),
(3, CURRENT_DATE - INTERVAL '10 days', 1),
(3, CURRENT_DATE - INTERVAL '12 days', 2),
(3, CURRENT_DATE - INTERVAL '15 days', 3);
