-- Create students table
CREATE TABLE IF NOT EXISTS students (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    codeforces_handle VARCHAR(100) UNIQUE,
    current_rating INTEGER DEFAULT 0,
    max_rating INTEGER DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    email_reminders_enabled BOOLEAN DEFAULT true,
    reminder_count INTEGER DEFAULT 0,
    last_submission_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create contests table
CREATE TABLE IF NOT EXISTS contests (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
    contest_id INTEGER NOT NULL,
    contest_name VARCHAR(255) NOT NULL,
    rank INTEGER,
    old_rating INTEGER,
    new_rating INTEGER,
    rating_change INTEGER,
    problems_solved INTEGER DEFAULT 0,
    total_problems INTEGER DEFAULT 0,
    contest_time TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create problems table
CREATE TABLE IF NOT EXISTS problems (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
    problem_id VARCHAR(100) NOT NULL,
    problem_name VARCHAR(255) NOT NULL,
    rating INTEGER,
    tags TEXT[],
    solved_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create submissions table for heatmap
CREATE TABLE IF NOT EXISTS submissions (
    id SERIAL PRIMARY KEY,
    student_id INTEGER REFERENCES students(id) ON DELETE CASCADE,
    submission_date DATE NOT NULL,
    problem_count INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, submission_date)
);

-- Create system settings table
CREATE TABLE IF NOT EXISTS system_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default cron settings
INSERT INTO system_settings (setting_key, setting_value) 
VALUES 
    ('cron_time', '02:00'),
    ('cron_frequency', 'daily')
ON CONFLICT (setting_key) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_students_handle ON students(codeforces_handle);
CREATE INDEX IF NOT EXISTS idx_contests_student_time ON contests(student_id, contest_time);
CREATE INDEX IF NOT EXISTS idx_problems_student_solved ON problems(student_id, solved_at);
CREATE INDEX IF NOT EXISTS idx_submissions_student_date ON submissions(student_id, submission_date);
