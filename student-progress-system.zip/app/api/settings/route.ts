import { type NextRequest, NextResponse } from "next/server"

// Mock settings storage
let settings = {
  cron_time: "02:00",
  cron_frequency: "daily",
  email_enabled: true,
  email_template:
    "Hi {name},\n\nWe noticed you haven't submitted any solutions on Codeforces in the last 7 days. Keep up your problem-solving momentum!\n\nBest regards,\nStudent Progress Team",
  inactivity_threshold: "7",
}

export async function GET() {
  return NextResponse.json(settings)
}

export async function PUT(request: NextRequest) {
  const body = await request.json()

  // In real app, update database
  settings = { ...settings, ...body }
  console.log("Settings updated:", settings)

  return NextResponse.json({ success: true, settings })
}
