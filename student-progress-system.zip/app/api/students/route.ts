import { type NextRequest, NextResponse } from "next/server"

// Mock database operations
const students = [
  {
    id: 1,
    name: "Alice Johnson",
    email: "alice@example.com",
    phone: "+1234567890",
    codeforces_handle: "alice_codes",
    current_rating: 1542,
    max_rating: 1687,
    last_updated: "2024-01-15T10:30:00Z",
    email_reminders_enabled: true,
    reminder_count: 2,
    last_submission_date: "2024-01-13T14:20:00Z",
  },
]

export async function GET() {
  return NextResponse.json(students)
}

export async function POST(request: NextRequest) {
  const body = await request.json()
  const newStudent = {
    id: Date.now(),
    ...body,
    current_rating: 0,
    max_rating: 0,
    last_updated: new Date().toISOString(),
    email_reminders_enabled: true,
    reminder_count: 0,
    last_submission_date: new Date().toISOString(),
  }

  students.push(newStudent)

  // Simulate fetching Codeforces data
  if (newStudent.codeforces_handle) {
    // In real app, this would call Codeforces API
    setTimeout(() => {
      console.log(`Fetching data for ${newStudent.codeforces_handle}`)
    }, 1000)
  }

  return NextResponse.json(newStudent, { status: 201 })
}
