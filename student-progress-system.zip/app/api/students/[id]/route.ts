import { type NextRequest, NextResponse } from "next/server"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const body = await request.json()
  const id = Number.parseInt(params.id)

  // In real app, update database
  console.log(`Updating student ${id}:`, body)

  return NextResponse.json({ success: true })
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const id = Number.parseInt(params.id)

  // In real app, delete from database
  console.log(`Deleting student ${id}`)

  return NextResponse.json({ success: true })
}
