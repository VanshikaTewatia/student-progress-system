"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Mail, Database, Bell, Save } from "lucide-react"

export default function SettingsPanel() {
  const [cronTime, setCronTime] = useState("02:00")
  const [cronFrequency, setCronFrequency] = useState("daily")
  const [emailEnabled, setEmailEnabled] = useState(true)
  const [emailTemplate, setEmailTemplate] = useState(
    "Hi {name},\n\nWe noticed you haven't submitted any solutions on Codeforces in the last 7 days. Keep up your problem-solving momentum!\n\nBest regards,\nStudent Progress Team",
  )
  const [inactivityThreshold, setInactivityThreshold] = useState("7")
  const [lastSyncTime, setLastSyncTime] = useState("2024-01-15T02:00:00Z")

  const handleSaveSettings = () => {
    // In a real app, this would save to the database
    console.log("Settings saved:", {
      cronTime,
      cronFrequency,
      emailEnabled,
      emailTemplate,
      inactivityThreshold,
    })
  }

  const handleManualSync = () => {
    // In a real app, this would trigger a manual sync
    setLastSyncTime(new Date().toISOString())
    console.log("Manual sync triggered")
  }

  return (
    <div className="space-y-6">
      {/* Data Synchronization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Data Synchronization
          </CardTitle>
          <CardDescription>Configure when and how often Codeforces data is synchronized</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cron-time">Sync Time</Label>
              <Input id="cron-time" type="time" value={cronTime} onChange={(e) => setCronTime(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cron-frequency">Frequency</Label>
              <Select value={cronFrequency} onValueChange={setCronFrequency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="manual">Manual Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <div>
              <div className="font-medium">Last Sync</div>
              <div className="text-sm text-muted-foreground">{new Date(lastSyncTime).toLocaleString()}</div>
            </div>
            <Button onClick={handleManualSync} variant="outline">
              Sync Now
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Email Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Email Notifications
          </CardTitle>
          <CardDescription>Configure automatic email reminders for inactive students</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="email-enabled">Enable Email Reminders</Label>
              <p className="text-sm text-muted-foreground">Send automatic emails to inactive students</p>
            </div>
            <Switch id="email-enabled" checked={emailEnabled} onCheckedChange={setEmailEnabled} />
          </div>

          {emailEnabled && (
            <>
              <div className="space-y-2">
                <Label htmlFor="inactivity-threshold">Inactivity Threshold (days)</Label>
                <Select value={inactivityThreshold} onValueChange={setInactivityThreshold}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 days</SelectItem>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="14">14 days</SelectItem>
                    <SelectItem value="30">30 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email-template">Email Template</Label>
                <Textarea
                  id="email-template"
                  value={emailTemplate}
                  onChange={(e) => setEmailTemplate(e.target.value)}
                  rows={6}
                  placeholder="Use {name} to insert student name"
                />
                <p className="text-xs text-muted-foreground">
                  Available variables: {"{name}"}, {"{handle}"}, {"{days_inactive}"}
                </p>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            System Status
          </CardTitle>
          <CardDescription>Current system status and statistics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold text-green-600">Active</div>
              <div className="text-sm text-muted-foreground">Sync Status</div>
            </div>
            <div className="text-center p-4 bg-muted rounded-lg">
              <div className="text-2xl font-bold">24</div>
              <div className="text-sm text-muted-foreground">API Calls Today</div>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm">Next scheduled sync:</span>
              <Badge variant="outline">
                {new Date(
                  new Date().setHours(Number.parseInt(cronTime.split(":")[0]), Number.parseInt(cronTime.split(":")[1])),
                ).toLocaleString()}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Email reminders:</span>
              <Badge variant={emailEnabled ? "default" : "secondary"}>{emailEnabled ? "Enabled" : "Disabled"}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} className="flex items-center gap-2">
          <Save className="h-4 w-4" />
          Save Settings
        </Button>
      </div>
    </div>
  )
}
