"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowLeft, TrendingUp, Calendar, Target } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"

interface Student {
  id: number
  name: string
  email: string
  phone: string
  codeforces_handle: string
  current_rating: number
  max_rating: number
  last_updated: string
  email_reminders_enabled: boolean
  reminder_count: number
  last_submission_date: string
}

interface Contest {
  id: number
  contest_name: string
  rank: number
  old_rating: number
  new_rating: number
  rating_change: number
  problems_solved: number
  total_problems: number
  contest_time: string
}

interface Problem {
  id: number
  problem_name: string
  rating: number
  tags: string[]
  solved_at: string
}

interface StudentProfileProps {
  student: Student
  onBack: () => void
}

export default function StudentProfile({ student, onBack }: StudentProfileProps) {
  const [contestFilter, setContestFilter] = useState("30")
  const [problemFilter, setProblemFilter] = useState("30")
  const [contests, setContests] = useState<Contest[]>([])
  const [problems, setProblems] = useState<Problem[]>([])
  const [heatmapData, setHeatmapData] = useState<{ date: string; count: number }[]>([])

  // Mock data - in real app, this would come from API
  useEffect(() => {
    const mockContests: Contest[] = [
      {
        id: 1,
        contest_name: "Codeforces Round #900",
        rank: 234,
        old_rating: 1500,
        new_rating: 1542,
        rating_change: 42,
        problems_solved: 3,
        total_problems: 6,
        contest_time: "2024-01-10T14:00:00Z",
      },
      {
        id: 2,
        contest_name: "Educational Round #150",
        rank: 456,
        old_rating: 1542,
        new_rating: 1687,
        rating_change: 145,
        problems_solved: 4,
        total_problems: 7,
        contest_time: "2023-12-25T14:00:00Z",
      },
      {
        id: 3,
        contest_name: "Div. 2 Round #899",
        rank: 123,
        old_rating: 1687,
        new_rating: 1654,
        rating_change: -33,
        problems_solved: 2,
        total_problems: 6,
        contest_time: "2023-12-15T14:00:00Z",
      },
    ]

    const mockProblems: Problem[] = [
      {
        id: 1,
        problem_name: "Theatre Square",
        rating: 1000,
        tags: ["math", "implementation"],
        solved_at: "2024-01-13T10:30:00Z",
      },
      {
        id: 2,
        problem_name: "Spreadsheets",
        rating: 1200,
        tags: ["implementation", "strings"],
        solved_at: "2024-01-12T15:45:00Z",
      },
      {
        id: 3,
        problem_name: "Ancient Berland Circus",
        rating: 1600,
        tags: ["geometry", "math"],
        solved_at: "2024-01-10T09:20:00Z",
      },
      {
        id: 4,
        problem_name: "Two Paths",
        rating: 1800,
        tags: ["graphs", "shortest paths"],
        solved_at: "2024-01-08T16:10:00Z",
      },
      {
        id: 5,
        problem_name: "Binary Search",
        rating: 1400,
        tags: ["binary search", "implementation"],
        solved_at: "2024-01-05T11:25:00Z",
      },
    ]

    // Generate heatmap data for the last 90 days
    const heatmap = []
    for (let i = 89; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const count = Math.random() > 0.7 ? Math.floor(Math.random() * 5) + 1 : 0
      heatmap.push({
        date: date.toISOString().split("T")[0],
        count,
      })
    }

    setContests(mockContests)
    setProblems(mockProblems)
    setHeatmapData(heatmap)
  }, [])

  const getFilteredContests = () => {
    const days = Number.parseInt(contestFilter)
    const cutoff = new Date()
    cutoff.setDate(cutoff.getDate() - days)
    return contests.filter((contest) => new Date(contest.contest_time) >= cutoff)
  }

  const getFilteredProblems = () => {
    const days = Number.parseInt(problemFilter)
    const cutoff = new Date()
    cutoff.setDate(cutoff.getDate() - days)
    return problems.filter((problem) => new Date(problem.solved_at) >= cutoff)
  }

  const getRatingChartData = () => {
    const filteredContests = getFilteredContests().sort(
      (a, b) => new Date(a.contest_time).getTime() - new Date(b.contest_time).getTime(),
    )

    return filteredContests.map((contest) => ({
      date: new Date(contest.contest_time).toLocaleDateString(),
      rating: contest.new_rating,
      contest: contest.contest_name,
    }))
  }

  const getProblemStats = () => {
    const filteredProblems = getFilteredProblems()
    const totalProblems = filteredProblems.length
    const maxRating = Math.max(...filteredProblems.map((p) => p.rating), 0)
    const avgRating =
      totalProblems > 0 ? Math.round(filteredProblems.reduce((sum, p) => sum + p.rating, 0) / totalProblems) : 0
    const days = Number.parseInt(problemFilter)
    const avgPerDay = totalProblems > 0 ? (totalProblems / days).toFixed(1) : "0"

    return { totalProblems, maxRating, avgRating, avgPerDay }
  }

  const getRatingDistribution = () => {
    const filteredProblems = getFilteredProblems()
    const buckets = {
      "800-1000": 0,
      "1001-1200": 0,
      "1201-1400": 0,
      "1401-1600": 0,
      "1601-1800": 0,
      "1801-2000": 0,
      "2000+": 0,
    }

    filteredProblems.forEach((problem) => {
      const rating = problem.rating
      if (rating <= 1000) buckets["800-1000"]++
      else if (rating <= 1200) buckets["1001-1200"]++
      else if (rating <= 1400) buckets["1201-1400"]++
      else if (rating <= 1600) buckets["1401-1600"]++
      else if (rating <= 1800) buckets["1601-1800"]++
      else if (rating <= 2000) buckets["1801-2000"]++
      else buckets["2000+"]++
    })

    return Object.entries(buckets).map(([range, count]) => ({ range, count }))
  }

  const getHeatmapColor = (count: number) => {
    if (count === 0) return "bg-gray-100 dark:bg-gray-800"
    if (count === 1) return "bg-green-200 dark:bg-green-900"
    if (count === 2) return "bg-green-300 dark:bg-green-800"
    if (count === 3) return "bg-green-400 dark:bg-green-700"
    if (count === 4) return "bg-green-500 dark:bg-green-600"
    return "bg-green-600 dark:bg-green-500"
  }

  const problemStats = getProblemStats()
  const ratingData = getRatingChartData()
  const distributionData = getRatingDistribution()

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{student.name}</h1>
            <p className="text-muted-foreground">@{student.codeforces_handle}</p>
          </div>
        </div>

        {/* Student Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Rating</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{student.current_rating}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Max Rating</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{student.max_rating}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Last Submission</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-sm">{new Date(student.last_submission_date).toLocaleDateString()}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Contest History */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Contest History</CardTitle>
                  <CardDescription>Rating progression over time</CardDescription>
                </div>
                <Select value={contestFilter} onValueChange={setContestFilter}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="365">Last year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {ratingData.length > 0 ? (
                <>
                  <div className="h-64 mb-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={ratingData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="rating" stroke="#3b82f6" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-2">
                    {getFilteredContests().map((contest) => (
                      <div key={contest.id} className="flex justify-between items-center p-2 rounded border">
                        <div>
                          <div className="font-medium">{contest.contest_name}</div>
                          <div className="text-sm text-muted-foreground">
                            Rank: {contest.rank} | Problems: {contest.problems_solved}/{contest.total_problems}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">{contest.new_rating}</div>
                          <div className={`text-sm ${contest.rating_change >= 0 ? "text-green-600" : "text-red-600"}`}>
                            {contest.rating_change >= 0 ? "+" : ""}
                            {contest.rating_change}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center text-muted-foreground py-8">No contests found for the selected period</div>
              )}
            </CardContent>
          </Card>

          {/* Problem Solving Data */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Problem Solving Data</CardTitle>
                  <CardDescription>Statistics and progress</CardDescription>
                </div>
                <Select value={problemFilter} onValueChange={setProblemFilter}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold">{problemStats.totalProblems}</div>
                  <div className="text-sm text-muted-foreground">Total Problems</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{problemStats.maxRating}</div>
                  <div className="text-sm text-muted-foreground">Max Difficulty</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{problemStats.avgRating}</div>
                  <div className="text-sm text-muted-foreground">Avg Rating</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{problemStats.avgPerDay}</div>
                  <div className="text-sm text-muted-foreground">Avg/Day</div>
                </div>
              </div>

              {/* Rating Distribution Chart */}
              <div className="h-48 mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={distributionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="range" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Submission Heatmap */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Submission Heatmap</CardTitle>
            <CardDescription>Daily submission activity over the last 90 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="grid grid-cols-13 gap-1 min-w-max">
                {heatmapData.map((day, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-sm ${getHeatmapColor(day.count)}`}
                    title={`${day.date}: ${day.count} submissions`}
                  />
                ))}
              </div>
              <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                <span>Less</span>
                <div className="flex gap-1">
                  <div className="w-3 h-3 rounded-sm bg-gray-100 dark:bg-gray-800" />
                  <div className="w-3 h-3 rounded-sm bg-green-200 dark:bg-green-900" />
                  <div className="w-3 h-3 rounded-sm bg-green-300 dark:bg-green-800" />
                  <div className="w-3 h-3 rounded-sm bg-green-400 dark:bg-green-700" />
                  <div className="w-3 h-3 rounded-sm bg-green-500 dark:bg-green-600" />
                  <div className="w-3 h-3 rounded-sm bg-green-600 dark:bg-green-500" />
                </div>
                <span>More</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Problems */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Recent Problems Solved</CardTitle>
            <CardDescription>Latest problem solving activity</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Problem</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Tags</TableHead>
                  <TableHead>Solved At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {getFilteredProblems()
                  .slice(0, 10)
                  .map((problem) => (
                    <TableRow key={problem.id}>
                      <TableCell className="font-medium">{problem.problem_name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{problem.rating}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {problem.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{new Date(problem.solved_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
