"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Plus, Edit, Trash2, Download, Eye, Settings, Moon, Sun, Users, TrendingUp, Calendar, Mail } from "lucide-react"
import { useTheme } from "next-themes"
import StudentProfile from "./components/student-profile"
import SettingsPanel from "./components/settings-panel"

interface Student {
  id: number
  name: string
  email: string
  phone: string
  codeforces_handle: string
  current_rating: number
  max_rating: number
  last_updated: string
  email_reminders_enabled: boolean
  reminder_count: number
  last_submission_date: string
}

export default function StudentProgressSystem() {
  const [students, setStudents] = useState<Student[]>([])
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showSettingsDialog, setShowSettingsDialog] = useState(false)
  const [editingStudent, setEditingStudent] = useState<Student | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("students")
  const { theme, setTheme } = useTheme()

  const [newStudent, setNewStudent] = useState({
    name: "",
    email: "",
    phone: "",
    codeforces_handle: "",
  })

  // Mock data - in real app, this would come from API
  useEffect(() => {
    const mockStudents: Student[] = [
      {
        id: 1,
        name: "Alice Johnson",
        email: "alice@example.com",
        phone: "+1234567890",
        codeforces_handle: "alice_codes",
        current_rating: 1542,
        max_rating: 1687,
        last_updated: "2024-01-15T10:30:00Z",
        email_reminders_enabled: true,
        reminder_count: 2,
        last_submission_date: "2024-01-13T14:20:00Z",
      },
      {
        id: 2,
        name: "Bob Smith",
        email: "bob@example.com",
        phone: "+1234567891",
        codeforces_handle: "bob_solver",
        current_rating: 1234,
        max_rating: 1456,
        last_updated: "2024-01-15T10:30:00Z",
        email_reminders_enabled: true,
        reminder_count: 0,
        last_submission_date: "2024-01-10T09:15:00Z",
      },
      {
        id: 3,
        name: "Charlie Brown",
        email: "charlie@example.com",
        phone: "+1234567892",
        codeforces_handle: "charlie_cf",
        current_rating: 1876,
        max_rating: 1923,
        last_updated: "2024-01-15T10:30:00Z",
        email_reminders_enabled: false,
        reminder_count: 5,
        last_submission_date: "2024-01-05T16:45:00Z",
      },
      {
        id: 4,
        name: "Diana Prince",
        email: "diana@example.com",
        phone: "+1234567893",
        codeforces_handle: "diana_dev",
        current_rating: 1098,
        max_rating: 1298,
        last_updated: "2024-01-15T10:30:00Z",
        email_reminders_enabled: true,
        reminder_count: 1,
        last_submission_date: "2024-01-14T11:30:00Z",
      },
      {
        id: 5,
        name: "Eve Wilson",
        email: "eve@example.com",
        phone: "+1234567894",
        codeforces_handle: "eve_expert",
        current_rating: 2134,
        max_rating: 2234,
        last_updated: "2024-01-15T10:30:00Z",
        email_reminders_enabled: true,
        reminder_count: 3,
        last_submission_date: "2024-01-01T08:00:00Z",
      },
    ]
    setStudents(mockStudents)
  }, [])

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.codeforces_handle.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddStudent = () => {
    const student: Student = {
      id: Date.now(),
      ...newStudent,
      current_rating: 0,
      max_rating: 0,
      last_updated: new Date().toISOString(),
      email_reminders_enabled: true,
      reminder_count: 0,
      last_submission_date: new Date().toISOString(),
    }
    setStudents([...students, student])
    setNewStudent({ name: "", email: "", phone: "", codeforces_handle: "" })
    setShowAddDialog(false)
  }

  const handleEditStudent = () => {
    if (editingStudent) {
      setStudents(students.map((s) => (s.id === editingStudent.id ? editingStudent : s)))
      setShowEditDialog(false)
      setEditingStudent(null)
    }
  }

  const handleDeleteStudent = (id: number) => {
    setStudents(students.filter((s) => s.id !== id))
  }

  const downloadCSV = () => {
    const headers = ["Name", "Email", "Phone", "CF Handle", "Current Rating", "Max Rating", "Last Updated"]
    const csvContent = [
      headers.join(","),
      ...students.map((s) =>
        [
          s.name,
          s.email,
          s.phone,
          s.codeforces_handle,
          s.current_rating,
          s.max_rating,
          new Date(s.last_updated).toLocaleDateString(),
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "students.csv"
    a.click()
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 2100) return "text-red-600"
    if (rating >= 1900) return "text-purple-600"
    if (rating >= 1600) return "text-blue-600"
    if (rating >= 1400) return "text-cyan-600"
    if (rating >= 1200) return "text-green-600"
    return "text-gray-600"
  }

  const getRatingBadge = (rating: number) => {
    if (rating >= 2100) return <Badge variant="destructive">Expert+</Badge>
    if (rating >= 1900) return <Badge className="bg-purple-600">Expert</Badge>
    if (rating >= 1600) return <Badge className="bg-blue-600">Candidate Master</Badge>
    if (rating >= 1400) return <Badge className="bg-cyan-600">Specialist</Badge>
    if (rating >= 1200) return <Badge className="bg-green-600">Pupil</Badge>
    return <Badge variant="secondary">Newbie</Badge>
  }

  const isInactive = (lastSubmission: string) => {
    const daysSince = Math.floor((Date.now() - new Date(lastSubmission).getTime()) / (1000 * 60 * 60 * 24))
    return daysSince >= 7
  }

  const getStats = () => {
    const totalStudents = students.length
    const activeStudents = students.filter((s) => !isInactive(s.last_submission_date)).length
    const avgRating = Math.round(students.reduce((sum, s) => sum + s.current_rating, 0) / totalStudents)
    const inactiveStudents = totalStudents - activeStudents

    return { totalStudents, activeStudents, avgRating, inactiveStudents }
  }

  const stats = getStats()

  if (selectedStudent) {
    return <StudentProfile student={selectedStudent} onBack={() => setSelectedStudent(null)} />
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold">Student Progress Management</h1>
            <p className="text-muted-foreground">Track and manage Codeforces progress</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button variant="outline" onClick={() => setShowSettingsDialog(true)}>
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalStudents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Students</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.activeStudents}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.avgRating}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inactive Students</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.inactiveStudents}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <CardTitle>Students</CardTitle>
                <CardDescription>Manage student profiles and track their progress</CardDescription>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                <Input
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full sm:w-64"
                />
                <div className="flex gap-2">
                  <Button onClick={downloadCSV} variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    CSV
                  </Button>
                  <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Student
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add New Student</DialogTitle>
                        <DialogDescription>Enter student details to add them to the system.</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name">Name</Label>
                          <Input
                            id="name"
                            value={newStudent.name}
                            onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={newStudent.email}
                            onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            value={newStudent.phone}
                            onChange={(e) => setNewStudent({ ...newStudent, phone: e.target.value })}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="handle">Codeforces Handle</Label>
                          <Input
                            id="handle"
                            value={newStudent.codeforces_handle}
                            onChange={(e) => setNewStudent({ ...newStudent, codeforces_handle: e.target.value })}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={handleAddStudent}>Add Student</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden sm:table-cell">Email</TableHead>
                    <TableHead className="hidden md:table-cell">Phone</TableHead>
                    <TableHead>CF Handle</TableHead>
                    <TableHead>Current Rating</TableHead>
                    <TableHead className="hidden lg:table-cell">Max Rating</TableHead>
                    <TableHead className="hidden xl:table-cell">Last Updated</TableHead>
                    <TableHead className="hidden lg:table-cell">Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">
                        <div>
                          <div>{student.name}</div>
                          {isInactive(student.last_submission_date) && (
                            <Badge variant="destructive" className="text-xs mt-1">
                              Inactive
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">{student.email}</TableCell>
                      <TableCell className="hidden md:table-cell">{student.phone}</TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <span className="font-mono text-sm">{student.codeforces_handle}</span>
                          {getRatingBadge(student.current_rating)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`font-bold ${getRatingColor(student.current_rating)}`}>
                          {student.current_rating}
                        </span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <span className={`font-bold ${getRatingColor(student.max_rating)}`}>{student.max_rating}</span>
                      </TableCell>
                      <TableCell className="hidden xl:table-cell">
                        {new Date(student.last_updated).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-center gap-2">
                          {student.email_reminders_enabled ? (
                            <Mail className="h-4 w-4 text-green-600" />
                          ) : (
                            <Mail className="h-4 w-4 text-gray-400" />
                          )}
                          {student.reminder_count > 0 && (
                            <Badge variant="outline" className="text-xs">
                              {student.reminder_count} reminders
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => setSelectedStudent(student)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setEditingStudent(student)
                              setShowEditDialog(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteStudent(student.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Student</DialogTitle>
              <DialogDescription>Update student information.</DialogDescription>
            </DialogHeader>
            {editingStudent && (
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-name">Name</Label>
                  <Input
                    id="edit-name"
                    value={editingStudent.name}
                    onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-email">Email</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editingStudent.email}
                    onChange={(e) => setEditingStudent({ ...editingStudent, email: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-phone">Phone</Label>
                  <Input
                    id="edit-phone"
                    value={editingStudent.phone}
                    onChange={(e) => setEditingStudent({ ...editingStudent, phone: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-handle">Codeforces Handle</Label>
                  <Input
                    id="edit-handle"
                    value={editingStudent.codeforces_handle}
                    onChange={(e) => setEditingStudent({ ...editingStudent, codeforces_handle: e.target.value })}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="email-reminders"
                    checked={editingStudent.email_reminders_enabled}
                    onCheckedChange={(checked) =>
                      setEditingStudent({ ...editingStudent, email_reminders_enabled: checked })
                    }
                  />
                  <Label htmlFor="email-reminders">Enable email reminders</Label>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button onClick={handleEditStudent}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Settings Dialog */}
        <Dialog open={showSettingsDialog} onOpenChange={setShowSettingsDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>System Settings</DialogTitle>
              <DialogDescription>Configure system-wide settings and preferences.</DialogDescription>
            </DialogHeader>
            <SettingsPanel />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
